import SolidAuthSwiftTools

print("Hello, world!")
