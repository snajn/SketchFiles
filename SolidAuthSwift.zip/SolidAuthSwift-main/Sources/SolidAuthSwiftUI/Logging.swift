//
//  Logging.swift
//  
//
//  Created by Christopher G Prince on 7/24/21.
//

import Logging

public var logger = Logger(label: "")
