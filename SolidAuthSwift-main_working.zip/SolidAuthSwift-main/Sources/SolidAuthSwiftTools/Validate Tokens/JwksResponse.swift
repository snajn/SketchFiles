//
//  JwksResponse.swift
//  
//
//  Created by Christopher G Prince on 7/29/21.
//

import Foundation
import JWTKit

public struct JwksResponse {
    public let jwks: JWKS
}

