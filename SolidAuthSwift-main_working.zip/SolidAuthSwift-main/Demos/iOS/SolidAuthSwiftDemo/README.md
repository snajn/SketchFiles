# SolidAuthSwiftDemo
A demo of using the SolidAuthSwift library
